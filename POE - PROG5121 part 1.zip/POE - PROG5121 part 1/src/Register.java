public class Register {
    private String username;
    private String password;
    private String cellPhone;
    private String firstName;
    private String lastName;

    // Validate username (must be at least 6 characters and contain "_")
    public boolean checkUserName(String username) {
        return username.length() >= 6 && username.contains("_");
    }

    // Validate password (uppercase, number, special char, min 8 chars)
    public boolean checkPasswordComplexity(String password) {
        boolean hasUpper = password.matches(".*[A-Z].*");
        boolean hasNumber = password.matches(".*\\d.*");
        boolean hasSpecial = password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
        boolean longEnough = password.length() >= 8;

        return hasUpper && hasNumber && hasSpecial && longEnough;
    }

    // Validate South African phone number
    public boolean checkCellPhoneNumber(String cellPhone) {
        return cellPhone.matches("\\+27\\d{9}");
    }

    // Registration method
    public String registerUser(String username, String password, String cellPhone, String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;

        StringBuilder messages = new StringBuilder();

        if (checkUserName(username)) {
            this.username = username;
            messages.append("Username successfully captured.\n");
        } else {
            messages.append("Username is not correctly formatted. It must contain an underscore and be at least 6 characters long.\n");
        }

        if (checkPasswordComplexity(password)) {
            this.password = password;
            messages.append("Password successfully captured.\n");
        } else {
            messages.append("Password is not correctly formatted. It must be at least 8 characters long, contain a capital letter, a number, and a special character.\n");
        }

        if (checkCellPhoneNumber(cellPhone)) {
            this.cellPhone = cellPhone;
            messages.append("Cell phone number successfully added.");
        } else {
            messages.append("Cell phone number is incorrectly formatted. It must start with '+27' and be followed by 9 digits.");
        }

        return messages.toString();
    }

    // Getters for login validation
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getCellPhone() {
        return cellPhone;
    }
}
