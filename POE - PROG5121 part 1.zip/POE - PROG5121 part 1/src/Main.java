
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String firstName;
        String lastName;
        String username = "";
        String password = "";
        String cellPhoneNumber = "+27";

        // Input for first name
        System.out.println("Enter your first name:");
        firstName = scanner.nextLine();

        // Input for last name
        System.out.println("Enter your last name:");
        lastName = scanner.nextLine();

        // Username input loop
        boolean isUsernameValid;
        do {
            System.out.println("Enter a username (at least 6 characters and contains an underscore):");
            username = scanner.nextLine();
            isUsernameValid = isValidUsername(username);
            if (!isUsernameValid) {
                System.out.println("Username must be at least 6 characters long and contain an underscore.");
            }
        } while (!isUsernameValid);
        System.out.println("Username successfully captured: " + username);

        // Password input loop
        boolean isPasswordValid;
        do {
            System.out.println("Enter your password (8+ characters, capital letter, number, special character):");
            password = scanner.nextLine();
            isPasswordValid = isValidPassword(password);
            if (!isPasswordValid) {
                System.out.println("Password must be at least 8 characters, include an uppercase letter, a number, and a special character.");
            }
        } while (!isPasswordValid);
        System.out.println("Password successfully captured.");

        // Cellphone input loop
        boolean isCellValid;
        do {
            System.out.println("Enter your cellphone number (must start with +27 and be 10 characters long):");
            cellPhoneNumber = scanner.nextLine();
            isCellValid = isValidCellphone(cellPhoneNumber);
            if (!isCellValid) {
                System.out.println("Cellphone number must start with '+27' and be exactly 10 characters.");
            }
        } while (!isCellValid);
        System.out.println("Cellphone number successfully added: " + cellPhoneNumber);

        // Close scanner to avoid resource leak
        scanner.close();
    }

    // Username validation
    public static boolean isValidUsername(String username) {
        return username.length() >= 6 && username.contains("_");
    }

    // Password validation with regex
    public static boolean isValidPassword(String password) {
        String regex = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[^a-zA-Z0-9]).{8,}$";
        return password.matches(regex);
    }

    // Cellphone validation: must start with +27 and have exactly 10 digits
    public static boolean isValidCellphone(String number) {
        return number.startsWith("+27") && number.length() == 13;  // Corrected to 13 to include '+27'
    }
}