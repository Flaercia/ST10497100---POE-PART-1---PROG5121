import java.util.Scanner;

public class Login {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Register register = new Register();

        // === Registration ===
        System.out.println("=== Registration ===");
        System.out.print("Enter first name: ");
        String first = scanner.nextLine();

        System.out.print("Enter last name: ");
        String last = scanner.nextLine();

        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.print("Enter South African cellphone number (+27...): ");
        String phone = scanner.nextLine();

        // Call registration method and show feedback
        System.out.println("\n" + register.registerUser(username, password, phone, first, last));

        // === Login ===
        System.out.println("\n=== Login ===");
        System.out.print("Enter username: ");
        String loginUsername = scanner.nextLine();

        System.out.print("Enter password: ");
        String loginPassword = scanner.nextLine();

        // Verify credentials
        if (loginUsername.equals(register.getUsername()) && loginPassword.equals(register.getPassword())) {
            System.out.println("Welcome " + register.getFirstName() + " " + register.getLastName() + ", it is great to see you again.");
        } else {
            System.out.println("Username or password incorrect, please try again.");
        }

        scanner.close();
    }
}